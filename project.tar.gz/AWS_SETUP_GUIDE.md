# AWS EC2 & S3 Deployment Guide

This guide walks you through deploying the **Student Document Management System** on an **AWS EC2** instance using **AWS S3** for secure document storage.

---

## Architecture Overview

```
[ User Browser ]
       │
       ▼ (HTTP / HTTPS: Port 80 / 443)
┌─────────────────────────────────────────────────────────┐
│ AWS EC2 (Ubuntu 22.04 / 24.04 LTS)                      │
│                                                         │
│  ┌────────────────────────┐                             │
│  │ Frontend (Nginx)       │ :80                         │
│  └───────────┬────────────┘                             │
│              │ /api proxy                               │
│              ▼                                          │
│  ┌────────────────────────┐                             │
│  │ Backend (Node/Express) │ :5000 (Internal)            │
│  └─────┬──────────────┬───┘                             │
│        │              │                                 │
│        ▼              ▼                                 │
│  ┌───────────┐  [ AWS S3 Bucket ] (Presigned URLs)      │
│  │Postgres DB│  (Private academic docs storage)         │
│  └───────────┘                                          │
└─────────────────────────────────────────────────────────┘
```

---

## Step 1: AWS S3 Bucket Setup

1. Log into your [AWS Management Console](https://console.aws.amazon.com/) and search for **S3**.
2. Click **Create bucket**.
3. **Bucket name**: Enter a unique name, e.g., `student-docs-milan-2026` (save this name).
4. **AWS Region**: Select your nearest region, e.g., `ap-south-1` (Mumbai) or `us-east-1` (N. Virginia).
5. **Block Public Access**: Keep **"Block all public access" ENABLED (Checked)**. Documents are accessed securely via temporary presigned URLs.
6. Leave other settings as default and click **Create bucket**.

### Configure S3 CORS
1. Open your created bucket → Go to the **Permissions** tab.
2. Scroll down to **Cross-origin resource sharing (CORS)** → Click **Edit**.
3. Paste the following JSON configuration and click **Save changes**:

```json
[
  {
    "AllowedHeaders": ["*"],
    "AllowedMethods": ["GET", "PUT", "POST", "DELETE", "HEAD"],
    "AllowedOrigins": ["*"],
    "ExposeHeaders": ["ETag"],
    "MaxAgeSeconds": 3000
  }
]
```
*(Note: In production with a custom domain, you can replace `"*"` with your domain like `"https://yourdomain.com"`).*

---

## Step 2: S3 Permissions (Choose Option A or Option B)

### Option A: IAM Role for EC2 (Recommended - No hardcoded keys needed!)
1. Go to AWS **IAM** Console → **Roles** → **Create role**.
2. Select **AWS service** → Use case: **EC2** → Click **Next**.
3. Click **Create policy** (opens in new tab) → Select JSON and paste:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket"
      ],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME"
    }
  ]
}
```
*(Replace `YOUR_BUCKET_NAME` with your actual bucket name).*
4. Name the policy `StudentDocsS3Policy` and save.
5. Return to the Role creation tab, select `StudentDocsS3Policy`, name the role `EC2-StudentDocs-Role`, and finish creating it.
6. (Later, attach this role to your EC2 instance in EC2 Console: **Actions → Security → Modify IAM role**).

### Option B: IAM User with Access Keys
1. Go to **IAM** → **Users** → **Create user**. Name it `student-docs-user`.
2. Attach the `StudentDocsS3Policy` created above.
3. Once created, go to **Security credentials** tab → **Create access key** (Application running outside AWS).
4. Save the **Access Key ID** and **Secret Access Key**.

---

## Step 3: Launch AWS EC2 Instance

1. Go to **EC2 Console** → Click **Launch Instance**.
2. **Name**: `student-doc-system`.
3. **AMI (Operating System)**: **Ubuntu Server 24.04 LTS** or **22.04 LTS** (64-bit x86).
4. **Instance type**: `t2.micro` or `t3.micro` (Free Tier eligible).
5. **Key pair**: Create a new key pair (e.g. `student-docs-key.pem`) and download it.
6. **Network settings / Security Group**:
   - Check **Allow SSH traffic** from: **My IP** (or Anywhere `0.0.0.0/0`).
   - Check **Allow HTTP traffic from the internet** (Port 80).
   - Check **Allow HTTPS traffic from the internet** (Port 443).
7. **Storage**: Set to **20 GB gp3** (Free tier covers up to 30 GB).
8. Click **Launch instance**.
9. *(If using Option A)*: Select your instance → **Actions** → **Security** → **Modify IAM role** → Attach `EC2-StudentDocs-Role`.

---

## Step 4: Deploy Using the Automated Script

1. Open your terminal on your computer and connect to EC2 via SSH:
   ```bash
   chmod 400 student-docs-key.pem
   ssh -i student-docs-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
   ```

2. Clone your project code onto the EC2 instance:
   ```bash
   git clone <YOUR_GIT_REPOSITORY_URL> student-doc-system
   cd student-doc-system
   ```
   *(Or copy files using `scp` if you don't use Git)*.

3. Make the deploy script executable:
   ```bash
   chmod +x deploy-ec2.sh update-ec2.sh
   ```

4. Create your `.env.production` file:
   ```bash
   cp .env.production.example .env.production
   nano .env.production
   ```
   Update the following variables:
   - `DB_PASSWORD`: Set a strong database password.
   - `JWT_SECRET`: Random string (can generate using `openssl rand -hex 32`).
   - `FRONTEND_URL`: `http://YOUR_EC2_PUBLIC_IP` (or your domain).
   - `AWS_REGION`: Your S3 bucket region (e.g., `us-east-1` or `ap-south-1`).
   - `AWS_S3_BUCKET`: Your exact S3 bucket name.
   - `AWS_ACCESS_KEY_ID` & `AWS_SECRET_ACCESS_KEY`:
     - If you attached an IAM Role in Step 2 Option A: **Leave empty!**
     - If using Option B: Enter your keys.

   Save and exit `nano` (`Ctrl + O`, `Enter`, then `Ctrl + X`).

5. Run the deployment script:
   ```bash
   ./deploy-ec2.sh
   ```

The script will automatically:
- Configure 2GB swap space (prevents memory exhaustion on t2/t3.micro).
- Install Docker & Docker Compose plugin.
- Build frontend with Vite & backend with Prisma.
- Apply database migrations/schema automatically.
- Start all services with Nginx reverse proxy.

---

## Step 5: Test & Access the Application

1. Open your browser and navigate to:
   ```
   http://YOUR_EC2_PUBLIC_IP
   ```
2. You will see the **StudentDocs** login/register page!
3. Register a new user account and try uploading a test marksheet/PDF document.
4. Verify document view and deletion.

---

## Maintenance & Management Commands

### Check logs
```bash
# View backend logs (API & Prisma)
sudo docker compose logs -f backend

# View frontend / Nginx logs
sudo docker compose logs -f frontend

# View database logs
sudo docker compose logs -f postgres
```

### Update the application after code changes
```bash
./update-ec2.sh
```

### Restart containers
```bash
sudo docker compose restart
```

### Stop containers
```bash
sudo docker compose down
```
